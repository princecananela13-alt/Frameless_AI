# Frameless_AI launcher (APK source)

Opens the Frameless_AI WebUI in its own app, with root access built in.
Needs: rooted phone + the Frameless_AI Magisk module installed.

## Build the APK
**Option A - Android Studio (PC):** open this folder, wait for Gradle sync, Build > Build APK(s).
**Option B - GitHub (no PC):**
1. Create a free GitHub repo and upload everything in this folder (keep the folders, including `.github`).
2. Open the repo > Actions > "Build Frameless_AI APK" > Run workflow.
3. When it finishes, download the `Frameless_AI-apk` artifact, unzip, install `app-debug.apk`.

## First run
Open Frameless_AI and allow root in Magisk. If the module is missing it tells you.
The app shows the UI bundled inside it. To update the UI, replace `app/src/main/assets/index.html` with the new `webroot/index.html`.
